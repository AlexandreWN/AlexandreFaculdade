package Captulo5;

public class main {

	/*
	 * Aula 04 - Fundamentos de Java game 2D
	 * +Listeners (escutadores de Teclado ou Mouse)
	 * 
	 * Alunos: Alexandre Wilian Nikitin e Wyllyan Thibes
	 * Data: 14/09/2022
	 * */
	public static void main(String[] args) {
		System.out.println("Cap 05 - LISTENERS");
		moldura M =  new moldura();
	}

}
