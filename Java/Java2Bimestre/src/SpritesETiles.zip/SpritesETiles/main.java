package SpritesETiles;

public class main {
	/*
		Cap 08  - Aula 07 - Fundamentos de java game 2D
			-	Sprites
			-	Tiles
			
		Aluno : Alexandre Wilian Niktin
		Data: 17/10/2022
	*/
	public static void main(String[] args) {
		moldura m = new moldura();
		System.out.println("Alexande Wilian Nikitin");
		System.out.println("Cap08 - aula 07 - sprites e  tiles");
	}

}
