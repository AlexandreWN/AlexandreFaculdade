package Captulo06;

public class main {
    /*
    * Cap06  - Aula - Fundamentos de Java game 2D
    * Detectores de colisão
    * Identificar quando um objeto "bate" em outro
    * 
    * Autor: Alexandre Wilian Nikitin
    * Data: 23/09/2022
    */

    public static void main(String args[]){
        System.out.println("Capítulo 06 - Colision Detection");
        moldura M = new moldura();
    }
}
