package Captulo5Mouse;
/*
 * Data:11/09/2022
 * Autor: Alexandre Wilian Nikitin.
 */


public class Principal {

	public static void main(String[] args) {
		System.out.println("Cap 05 - LISTENERS");
		Moldura M = new Moldura();

	}

}
