package Desenhos_Geo;

public class Main {
	/*
	 * Aula 03 - fundamentos de Java game 2d
	 * 
	 * Desenhos geometricos e anima��o
	 * 
	 * Autro: Alexandre Wilian Nikitin
	 * Data: 24/08/2022
	 */
	public static void main(String[] args) {
		
		moldura mold = new moldura();
		
	}

}
