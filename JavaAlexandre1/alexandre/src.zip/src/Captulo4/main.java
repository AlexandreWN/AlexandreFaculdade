package Captulo4;

public class main {

	/*
	 *  Aula 03 -fundamentos de Java game 2D
	 *   + Captulo 4: Formas Geom�tricas
	 *   
	 *   Autor: Alexandre Wilian Nikitin, Wyllyan Thibes
	 *   Data: 31/08/2022
	 * */
	public static void main(String[] args) {
		System.out.println("Alexandre e Wyllyan");
		moldura M = new moldura();
	}

}
