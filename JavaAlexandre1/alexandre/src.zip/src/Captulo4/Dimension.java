package Captulo4;

public class Dimension {

}
