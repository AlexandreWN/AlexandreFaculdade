package teste;

public class principal {
	
	public static void main(String args[])
	{
		System.out.println("ola");
		System.out.println();
	}

}
