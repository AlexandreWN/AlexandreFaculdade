package LAYOUT;

public class principal {
	/*
	 * Aula 01 - fundamentos de Java game 2d
	 * 
	 * Layout Graphic2D
	 * Entendendo como funcionam os layouts dos paineis dentro da moldura
	 * 
	 * Autro: Alexandre Wilian Nikitin
	 * Data: 10/08/2022
	 */
	public static void main(String[] args) {
		System.out.println("Layouts");
		moldura mold1 = new moldura(500, 500, 200, 300, "a");
		moldura mold2 = new moldura(600, 600, 600, 600, "b");
		moldura mold3 = new moldura(200, 200, 100, 100, "c");
	}

}
